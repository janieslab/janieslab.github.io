readme for supplemental data for Janies et al. Cloning, Oreaster (Asteroidea: Echinodermata) larvae and the discovery of the adult in the life cycle

This archive includes 6 folders.
4 folders, (16S, COI, 12S-trnas, and trnas) include the four loci level datasets used in the phylogenetic analyses.
2 folders (trnas-frag, COI-frag) includ four sublocus level dataseets used in distance and SNP analyses.

for questions contact Dan Janies, djanies@uncc.edu
